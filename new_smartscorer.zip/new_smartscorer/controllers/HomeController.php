<?php

namespace Controllers;

use Illuminate\Http\Request;

class HomeController
{

    public function index()
    {
        echo json_encode(['status_code' => 200, 'message' =>  'hello']);
        // echo json_encode(['status_code' => 200, 'message' =>  bin2hex(random_bytes(32))]);
    }


    public function home(Request $request)
    {
        $userName = $request->userName;
        echo json_encode(['status_code' => 200, 'message' => "hi ! this is $userName"]);

    }
}
