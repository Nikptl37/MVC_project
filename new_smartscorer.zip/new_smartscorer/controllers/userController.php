<?php

namespace Controllers;

use App\Auth;
use Illuminate\Http\Request;
use Models\User;

class userController { 
   
    public function createUser(Request $request){

        $userName = $request->userName ?? '';
        $email = $request->email ?? '';
        $password = $request->password ?? '';

        User::create([
            'userName' => $userName,
            'email' => $email,
            'password' => $password,
            'createdAt' => date("Y-m-d H:i:s")
        ]);

        echo json_encode(['status' => 200, 'message' => 'create user successfully']);
    }

    public function login(){
        $data = json_decode(file_get_contents("php://input"), true);

        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';

        $finduser = User::findOne(['email' => $email]);
        if($finduser){
            if($finduser['password'] == $password){
               $token =  Auth::generateToken($finduser);
                echo json_encode(['status' => 200, 'token' => $token]); 
            }else{
                echo json_encode(['status' =>400 , 'message' => "enter the correct password"]); 
            }
        }else{
            echo json_encode(['status' => 404, 'message' => 'user not found']);
        }
    }

    public function userData(){
        $userData = Auth::user();

        echo json_encode(['status' => 200, 'message' => $userData]); 

    }

    public function logout(){
        Auth::logout();

        echo json_encode(['status' => 200, 'message' => "logout successfully"]);
    }
}   