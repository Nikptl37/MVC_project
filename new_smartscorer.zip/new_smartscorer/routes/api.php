<?php

// require_once __DIR__ . '/../app/middleware/AuthMiddleware.php';

use App\Router;
use App\Middleware\AuthMiddleware;
use Controllers\HomeController;
use Controllers\userController;

Router::get('/', [HomeController::class, 'index']);

Router::post('/home',[HomeController::class, 'home']);
Router::post('/register', [userController::class, 'createUser']);
Router::post('/login', [userController::class, 'login']);

Router::group(['middleware' => [AuthMiddleware::class]], function(){
    Router::post('/user', [userController::class, 'userData']);

    Router::post('/logout', [userController::class, 'logout']);
});

Router::dispatch();
