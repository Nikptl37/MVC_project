<?php

use Dotenv\Dotenv;

require_once '../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

require_once '../routes/api.php';

// Handle pre-flight requests (OPTIONS method) for CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0); // Exit early for OPTIONS requests
}