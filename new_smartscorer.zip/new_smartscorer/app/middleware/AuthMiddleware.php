<?php

namespace App\Middleware;

use App\Auth;

class AuthMiddleware {

    public static function handle($next){
        if(!Auth::check()){
            // http_response_code(400);
            echo json_encode(['status' => 400, 'message' => "Unauthorized"]); 
            exit;
        }
        
        $next();
    }

}
