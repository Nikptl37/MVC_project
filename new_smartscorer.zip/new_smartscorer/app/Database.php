<?php
namespace App; // If using Composer

use MongoDB\Client;
use Exception;

class Database {
    private static $instance = null;
    private $client;
    private $db;

    private function __construct() {
        try {
            $this->client = new Client("mongodb://localhost:27017");
            $this->db = $this->client->test_db; // Change 'my_database' to your actual DB name
        } catch (Exception $e) {
            die("MongoDB Connection Error: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getDB() {
        return $this->db;
    }
}