<?php


return [
    'DB_URL' => $_ENV['DB_URL'],
];